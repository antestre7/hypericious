import xbmc
from resources.lib.modules import control
control.moderator()

command = "RunPlugin(plugin://%s)" % control.addon().getAddonInfo('id')+"/pvr.py"
xbmc.executebuiltin("AlarmClock(MyAddonPVR,%s,120,false,true)" % command )

command = "RunPlugin(plugin://%s)" % (control.addon().getAddonInfo('id')+"/?action=login&hide=1")
xbmc.executebuiltin("AlarmClock('MyAddonLogin',%s,360,true,true)" % command)